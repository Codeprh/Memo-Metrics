package com.dianping.cat.message.io;

public interface TransportManager {
	public MessageSender getSender();
}
