package com.dianping.cat.config.content;

public interface ContentFetcher {

	public String getConfigContent(String configName);

}
